Aby odpalić układ należy uruchomić plik Saper.circ

Jeszcze nie udało nam zrealizować funkcjonalności aby gra sygnalizowała zakończenie rozgrywki
dolne, lewe pole ma czasami bugi i zawsze podaje 0.
